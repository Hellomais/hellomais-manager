// src/pages/Rooms/hooks/useRoom.js
import { useState, useEffect } from 'react';
import { useEvent } from '../../../contexts/EventContext';
import toast from 'react-hot-toast';

export function useRoom(id) {
  const { selectedEvent } = useEvent();
  const [room, setRoom] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (id) fetchRoom();
  }, [id, selectedEvent]);

  const fetchRoom = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await fetch(`https://dev-api.hellomais.com.br/rooms/${id}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-event-id': selectedEvent.id.toString()
        }
      });

      if (!response.ok) throw new Error('Falha ao carregar sala');

      const data = await response.json();
      setRoom(data);
    } catch (error) {
      toast.error('Erro ao carregar sala');
    } finally {
      setLoading(false);
    }
  };

  const updateRoom = async (data) => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await fetch(`https://dev-api.hellomais.com.br/rooms/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-event-id': selectedEvent.id.toString()
        },
        body: JSON.stringify(data)
      });

      if (!response.ok) throw new Error('Falha ao atualizar sala');

      const updatedData = await response.json();
      setRoom(updatedData);
      toast.success('Sala atualizada com sucesso!');
      return updatedData;
    } catch (error) {
      toast.error('Erro ao atualizar sala');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (status) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`https://dev-api.hellomais.com.br/rooms/${id}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-event-id': selectedEvent.id.toString()
        },
        body: JSON.stringify({ status })
      });

      if (!response.ok) throw new Error('Falha ao alterar status');

      toast.success('Status alterado com sucesso!');
      await fetchRoom(); // Recarrega a sala
    } catch (error) {
      toast.error('Erro ao alterar status');
      throw error;
    }
  };

  return {
    room,
    loading,
    fetchRoom,
    updateRoom,
    updateStatus
  };
}